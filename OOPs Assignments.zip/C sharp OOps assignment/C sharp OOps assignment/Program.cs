﻿using System;
class Employee
{
    private int EmpNo;
    private string EmpName;
    private double Salary;
    private double HRA;
    private double TA;
    private double DA;
    private double PF;
    private double TDS;
    private double NetSalary;
    private double GrossSalary;

    // Paeameterized Constructor
    // User defined
    public Employee(int EmpNo, string EmpName, double Salary )
    {
        this.EmpNo = EmpNo;
        this.EmpName = EmpName;
        this.Salary = Salary;
        if (Salary >= 20000)
        {
            this.HRA = Salary * 30 / 100;
            this.TA = Salary * 25 / 100;
            this.DA = Salary * 35 / 100;
            this.GrossSalary = Salary + HRA + TA + DA;
        } else if (Salary >= 15000) {
            this.HRA = Salary * 25 / 100;
            this.TA = Salary * 20 / 100;
            this.DA = Salary * 30 / 100;
            this.GrossSalary = Salary + HRA + TA + DA;
        } else if (Salary >= 10000) {
            this.HRA = Salary * 20 / 100;
            this.TA = Salary * 15 / 100;
            this.DA = Salary * 25 / 100;
            this.GrossSalary = Salary + HRA + TA + DA;
        } else if (Salary >= 5000) {
            this.HRA = Salary * 15 / 100;
            this.TA = Salary * 10 / 100;
            this.DA = Salary * 20 / 100;
            this.GrossSalary = Salary + HRA + TA + DA;
        } else {
            this.HRA = Salary + 10 / 100;
            this.TA = Salary + 5 / 100;
            this.DA = Salary + 15 / 100;
            this.GrossSalary = Salary + HRA + TA + DA;
        }
     }
    public void CalculateSalary()
    {
        this.PF = this.GrossSalary * 10 / 100;
        this.TDS = this.GrossSalary * 18 / 100;
        this.NetSalary = this.GrossSalary - (this.PF + this.TDS);
    }
    public double DisplayGrossSalary()
    {
        return this.GrossSalary;
    }
}
public class HelloWorld
{
    public static void Main(string[]args)
    {
        Employee emp = new Employee(101, "Demo Employee", 7000.00);

        double grossSalary = emp.DisplayGrossSalary();
        Console.WriteLine("Gross salary of employee" + grossSalary);
    }
}
    