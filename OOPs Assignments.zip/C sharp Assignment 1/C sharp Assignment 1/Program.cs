﻿
//1.	Write a Simple console Application Calculator with the help of Visual Studio .NET IDE which will perform following operations on two numbers:
//a.	Addition.

namespace MyDemo
{
    class program
    {
        static void Main(string[] args)
        {
            int a = 10;
            int b = 20;
            int c = a + b;
            Console.WriteLine(c);
        }
    }
}

// b.	Subtraction.

namespace MyDemo
{
    class program
    {
        static void Main(string[] args)
        {
            int a = 100;
            int b = 500;
            int c = a - b;
            Console.WriteLine(c);
        }
    }
}

// c.	Multiplication.

namespace MyDemo
{
    class void Main(string[] args)
    {
        int x = 10;
        int y = 100;
        int z = x * y


        Console.WriteLine(z);
    }

}
}

// d.	Division

namespace MyDemo
{
    class void Main(string[] args)
    {
        decimal x = 10;
        decimal y = 20;
        decimal z = x / y;

        Console.WriteLine(z);
    }
}
}

//  3.	Write a static method to accept param array of integers. The method should find the sum of all the integers passed and display the result. Write a client program to call the method.

using System;
  
class GFG
{

    // method for sum of integers in an array 
    static int sum(int[] arr, int n)
    {

        int sum = 0; // initialize sum

        // Iterate through all integers and 
        // add them to sum
        for (int i = 0; i < n; i++)
            sum += arr[i];

        return sum;
    }

    // Driver method
    public static void Main()
    {

        int[] arr = { 12, 3, 4, 15 };
        int n = arr.Length;

        Console.Write("Sum of given array is "
                               + sum(arr, n));
    }

}
System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C_sharp_Assignment_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
        }
    }
}


using System;
Console.WriteLine("1. Addtion ");

System.Console.WriteLine("2. Subtraction ");
System.Console.WriteLine("3. Multiplication ");

System.Console.WriteLine("4. Division ");

System.Console.WriteLine("Enter your choice---->");

int a, b, result:

int ch = System.Int32.Parse(System.Console.ReadLine());

switch (ch)

case 1:

    System.Console.WriteLine("Enter the value of A--->");

    a = Convert.ToInt32(System.Console.ReadLine()); System.Console.WriteLine("Enter the value of B>"):

b = Convert.ToInt32(System.Console.ReadLine()):

result = a + b:

System.Console.WriteLine("Addition of A and B>" + result);

    break:

case 2:

    System.Console.WriteLine("Enter the value of A-->"):

a Convert.object p = ToInt32(System.Console.ReadLine());

    System.Console.WriteLine("Enter the value of B b- Convert.ToInt32 (Console.ReadLine());



    reault - a - bi



    System.Console.WriteLine("Suntration of A and B + result); break:
    case

Console.WriteLine("Enter the value of A --->");

    a = Convert.ToInt32(System.Console.ReadLine());

    3 result = a b; System.Console.WriteLine("Multiplication of A and B -->" + result); break;

    System.Console.WriteLine("Enter the value of B --->"); b = Convert.ToInt32(Console.ReadLine()):

case 4:
    ToInt32(Console.ReadLine()); Console.WriteLine("Enter the value of B--->"); b = Convert.ToInt32(Console.ReadLine());

    System.Console.WriteLine("Enter the value of A--->"); result = a / b: Console.WriteLine("Devision of A and a--->" + result); break;

default:

    Console.WriteLine("Invalid choice");

    break:

System.Console.ReadKey(); object ToInt32(string v)
    {
        throw new NotImplementedException();
    }