﻿internal class EmployeeBase
{
    public void CalculateSalary()
    {
        this.PF = this.GrossSalary * 10 / 100;
        this.TDS = this.GrossSalary * 18 / 100;
        this.NetSalary = this.GrossSalary - (this.PF + this.TDS);
    }
    public virtual void CalculateSalary()
    {
        PF = GrossSalary * 10 / 100;
        TDS = GrossSalary * 18 / 100;
        NetSalary = GrossSalary - (PF + TDS);
    }
}