﻿using System;
class Employee
{
    protected int EmpNo { get; set; }
    protected string EmpName { get; set; }
    protected double Salary { get; set; }
    protected double HRA { get; set; }
    protected double TA { get; set; }
    protected double DA { get; set; }
    public double PF { get; private set; }
    protected double TDS { get; set; }
    protected double NetSalary { get; set; }
    protected double GrossSalary { get; set; }


    public Employee(int EmpNum, string EmpNm, double Sal)
    {
        EmpNo = EmpNo;
        EmpName = EmpNm;
        Salary = Sal;
        if (Salary < 5000)
        {
            HRA = Salary * 10 / 100;
            TA = Salary * 5 / 100;
            DA = Salary * 15 / 100;
            GrossSalary = Salary + HRA + TA + DA;
        }
        else if (Salary < 10000)
        {
            HRA = Salary * 15 / 100;
            TA = Salary * 10 / 100;
            DA = Salary * 20 / 100;
            GrossSalary = Salary + HRA + TA + DA;
        }
        else if (Salary < 15000)
        {
            HRA = Salary * 20 / 100;
            TA = Salary * 15 / 100;
            DA = Salary * 25 / 100;
            GrossSalary = Salary + HRA + TA + DA;
        }
        else if (Salary < 20000)
        {
            HRA = Salary * 25 / 100;
            TA = Salary * 20 / 100;
            DA = Salary * 30 / 100;
            GrossSalary = Salary + HRA + TA + DA;
        }
        else
        {
            HRA = Salary + 30 / 100;
            TA = Salary + 25 / 100;
            DA = Salary + 35 / 100;
            GrossSalary = Salary + HRA + TA + DA;
        }
    }
    public virtual void ClaculateSalary()
    {
        PF = GrossSalary * 10 / 100;
        TDS = GrossSalary * 18 / 100;
        NetSalary = GrossSalary - (PF + TDS);
    }

    public virtual void Gsal()
    {
        Console.WriteLine(GrossSalary);
    }

}



class Manager : Employee
{
    private double PetrolAllowance { get; set; }
    private double FoodAllowance { get; set; }
    private double OtherAllowance { get; set; }
    public Manager(int EmpNum, string EmpNm, double Sal) : base(EmpNum, EmpNm, Sal)
        {
        PetrolAllowance = Salary * 8 / 100;
        FoodAllowance = Salary * 13 / 100;
        OtherAllowance = Salary * 3 / 100;
    }
    public override void Gsal()
    {
        GrossSalary = (GrossSalary + PetrolAllowance + FoodAllowance + OtherAllowance);
        Console.WriteLine(GrossSalary);
    }

    public override void ClaculateSalary()
    {
        NetSalary = GrossSalary - (PF + TDS);
    }
}
class MarketingExecutive : Employee
{
    private double kilometertravel {  get; set; }
    private double TourAllowance { get; set; }
    private double TelephoneAllowance { get; set; }

    public MarketingExecutive(int EmpNum, string EmpNm, double Sal, double klt): base(EmpNum,EmpNm, Sal)
    {
        kilometertravel = klt;
        TourAllowance = kilometertravel * 5;
        TelephoneAllowance = 1000;
    }
    public override void Gsal()
    {
        GrossSalary = (GrossSalary + TourAllowance + TelephoneAllowance);
        Console.WriteLine(GrossSalary);
    }
    public override void ClaculateSalary()
    {
       NetSalary = GrossSalary - (PF + TDS);

    }

}
class MainProgram
{
    static void Main(string[] args)
    {
        //Employee Emp1 = new Employee(1, "Pratiksha",25000);
        //Manager M1 = new MarkE1 = new Manager(2,"Satya",30000);
        MarketingExecutive MarkE1 = new MarketingExecutive(3, " Abhijit", 35000, 10);
        //Emp1.Gsal();
        //M1.Gsal();
        MarkE1.Gsal();
    }
}
