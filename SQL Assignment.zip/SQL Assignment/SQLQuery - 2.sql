USE [sql_assignment]
CREATE TABLE Employees (
	id BIGINT PRIMARY KEY,
	FullName VARCHAR(60),
	DEPARTMENT INT,
	EMAIL VARCHAR(100)
);

INSERT INTO EMPLOYEE 
([id],[FullName],[DEPARTMENT],[EMAIL])
VALUES(1,'pratiksha',501,'prati@gmail.com'),
INSERT INTO EMPLOYEE
VALUES(2,'sayali',110,'sayali@gamil.com'),
INSERT INTO EMPLOYEE
VALUES(3,'anya',111,'anya@gmail.com')